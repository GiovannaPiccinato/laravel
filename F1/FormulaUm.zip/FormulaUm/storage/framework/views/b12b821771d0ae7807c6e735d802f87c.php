
<table border="2">
  <tr>
    <th>Nome da equipe </th>
    <th>Número de carros </th>
    <th>Número de Membros </th>
  </tr>
<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
    <td> <?php echo e($team->name); ?> </td>
    <td> <?php echo e($team->numOfCars); ?> </td>
    <td> <?php echo e($team->numOfMembers); ?> </td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\laravel\F1\FormulaUm\resources\views/team/index.blade.php ENDPATH**/ ?>